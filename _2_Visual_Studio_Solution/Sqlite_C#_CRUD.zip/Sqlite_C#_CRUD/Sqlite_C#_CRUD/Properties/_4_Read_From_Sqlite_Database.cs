﻿

// Basic Sqlite Database Access using C# on .NET Platform  
// 
// Make sure that Database is populated with some data before running this code
// (c) www.xanthium.in 2024


using System.Data.SQLite;

namespace SqliteDatabaseAccess
{
    class ReadSqliteDB
    {
        public static void Main()
        {
            String ConnectionString = @"Data Source=MySqliteDatabase.db";           // MySqliteDatabase.db will be in "\bin\Debug\net8.0\MySqliteDatabase.db"
            SQLiteConnection MyConnection = new SQLiteConnection(ConnectionString); // Create a SqliteConnection object called Connection

            // Make sure that Database is populated with some data before running this code

            String SQLQuerySelectAll = "SELECT * FROM Customers ";

            SQLiteCommand ReadDatafromTableCmd = new SQLiteCommand(SQLQuerySelectAll, MyConnection);

            Console.WriteLine(ReadDatafromTableCmd.CommandText);//Shows the SQL query inside MyCommand

            MyConnection.Open();

            SQLiteDataReader MyReader = ReadDatafromTableCmd.ExecuteReader();

            while (MyReader.Read())
            {

                int id        = MyReader.GetInt32(0);
                string name   = MyReader.GetString(1);
                int age       = MyReader.GetInt32(2);
                DateTime date = MyReader.GetDateTime(3);
                string email  = MyReader.GetString(4);
                float price   = MyReader.GetFloat(5);

                Console.WriteLine($"{id} {name} {age} {date} {email} {price}");

                //Console.WriteLine(MyReader.FieldCount);

            }

            MyConnection.Close();



        }//End of Main()
    }//End of Class
}//End of namespace